---
title: "{{{{notitle.title}}}}"
---


{{{{title.description}}}}

::: {.panel-tabset group="language"}
### Python

```{r}
#| child: paste0({{{{notitle.title}}}}, '_py.md')
```

### R

```{r}
#| child: paste0({{{{notitle.title}}}}, '_r.md')
```

:::


{{{{title.seealso}}}}

